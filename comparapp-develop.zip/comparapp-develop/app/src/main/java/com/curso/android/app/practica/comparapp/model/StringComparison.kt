package com.curso.android.app.practica.comparapp.model

data class StringComparison(var str1: String, var str2: String, var comparisonResult: Boolean = false)
